Thank you for downloading the 3D Pack from SenshiStock.  
Questions should be directed to Sarah@sailorastera.com

By using this stock you agree to the terms of my stock rules.  For the most up to date rules, visit http://senshistock.deviantart.com/journal/12576734/


General Rules

1) Reading the rules is considered asking for permission. You do not have to ask to use the stock in this gallery, just follow the rules.

2) Do not repost this stock or parts of this stock on other sites/accounts. This includes direct linking to the images.

3) Print Requests will be considered a mistake and ignored unless you NOTE ME and tell me that you are intentionally requesting a print.

4) I do really want to see your art, but you don't have to show it to me. Send a note or leave a comment on the front page or stock image you've used and I will check it out. I fav work made with my stock and I also promote it through #Thumbshare, stock communities, and my own features.

Rules for Photo Manipulations 

5) Credit MUST be given for stock used in photo manipulations. A link to this account in your comments is appropriate credit. For help, read this FAQ page.

6) For ALL photo manipulations you MUST GET PERMISSION from me before posting for DA Prints or for off site usage. This means ASKING BEFORE you post it off site or select a Print option.

Rules for Pose Reference 

7) This stock is UNRESTRICTED FOR POSE REFERENCE ONLY. This means that if you use the stock for reference alone, you can use it for anything, anywhere. This includes prints and commercial use.

8) Credit is greatly appreciated when the stock is used for solely pose reference, but it is not required. A link to this account in your comments is appropriate credit if you'd like to include it. For help, read this FAQ page.